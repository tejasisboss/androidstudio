package com.example.mycalcy;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ast.Scope;

public class home extends AppCompatActivity {

    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn_clear,btn_del,btn_percent,btn_div,btn_mul,btn_sub,btn_plus,btn_period,btn_bracket,btn_eq;
    TextView tv_cal,tv_ans;
    String process;
    boolean checkbracket = false;
    boolean checkeq = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btn0=findViewById(R.id.btn_0);
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        btn4=findViewById(R.id.btn4);
        btn5=findViewById(R.id.btn5);
        btn6=findViewById(R.id.btn6);
        btn7=findViewById(R.id.btn7);
        btn8=findViewById(R.id.btn8);
        btn9=findViewById(R.id.btn9);
        btn_div=findViewById(R.id.btn_div);
        btn_mul=findViewById(R.id.btn_mul);
        btn_sub=findViewById(R.id.btn_sub);
        btn_plus=findViewById(R.id.btn_plus);
        btn_clear=findViewById(R.id.btn_clear);
        btn_del=findViewById(R.id.btn_del);
        btn_percent=findViewById(R.id.btn_cent);
        btn_period=findViewById(R.id.btn_per);
        btn_bracket=findViewById(R.id.btn_brac);
        btn_eq=findViewById(R.id.btn_eq);
        tv_ans=findViewById(R.id.tv_ans);
        tv_cal=findViewById(R.id.tv_cal);

        btn_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_ans.setText("");
                tv_cal.setText("");
                checkeq = false;
            }
        });

        btn_eq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ans = Double.parseDouble(tv_ans.getText().toString());
                //tv_cal.setText(tv_ans.getText());
                //tv_ans.setText(tv_cal.getText().toString());
                //tv_cal.setText("");
                process = tv_cal.getText().toString();
                checkeq= true;
                tv_cal.setText(calulate(process));
                tv_ans.setText(" ");
            }
        });

        btn_period.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                tv_cal.setText(process + ".");
                checkeq = false;
            }
        });

        btn_percent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                tv_cal.setText(process + "%");
                tv_ans.setText(calulate(process));
                checkeq = false;
            }
        });

        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "0");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "0";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "0");
                    }
                }
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "1");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "1";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "1");
                    }
                }
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "2");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "2";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "2");
                    }
                }
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "3");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "3";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "3");
                    }
                }
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "4");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "4";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "4");
                    }
                }
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "5");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "5";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "5");
                    }
                }
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "6");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "6";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "6");
                    }
                }
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "7");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "7";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "7");
                    }
                }
            }
        });

        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "8");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "8";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "8");
                    }
                }
            }
        });

        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                if(checkeq){
                    process = " ";
                    tv_cal.setText(process + "9");
                    checkeq = false;
                }else{
                    if(process.contains("+")||process.contains("-")||process.contains("×")||process.contains("÷")){
                        process = process + "9";
                        tv_cal.setText(process);
                        tv_ans.setText(calulate(process));
                    }else{
                        tv_cal.setText(process + "9");
                    }
                }
            }
        });

        btn_bracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkbracket){
                    process = tv_cal.getText().toString();
                    process = process + ")";
                    tv_cal.setText(process);
                    checkbracket= false;
                    checkeq = false;
                    tv_ans.setText(calulate(process));
                }else{
                    process = tv_cal.getText().toString();
                    process = process + "(";
                    tv_cal.setText(process);
                    checkbracket= true;
                    checkeq = false;
                    //tv_ans.setText(calulate(process));
                }
            }
        });

        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                tv_cal.setText(process + "+");
                checkeq = false;
            }
        });

        btn_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                tv_cal.setText(process + "-");
                checkeq = false;
            }
        });

        btn_mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                tv_cal.setText(process + "×");
                checkeq = false;
            }
        });

        btn_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                tv_cal.setText(process + "÷");
                checkeq = false;
            }
        });

        btn_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process = tv_cal.getText().toString();
                process = process.substring(0, process.length() - 1);
                tv_cal.setText(process);
                tv_ans.setText(calulate(process));
            }
        });



    }

    private String calulate(String process) {
        process = process.replaceAll("×","*");
        process = process.replaceAll("%","/100");
        process = process.replaceAll("÷","/");

        Context rhino = Context.enter();

        rhino.setOptimizationLevel(-1);

        String finalResult = "";

        try {
            Scriptable scriptable = rhino.initStandardObjects();
            finalResult = rhino.evaluateString(scriptable,process,"javascript",1,null).toString();
        }catch (Exception e){
            finalResult="0";
        }

        return finalResult;
    }

}